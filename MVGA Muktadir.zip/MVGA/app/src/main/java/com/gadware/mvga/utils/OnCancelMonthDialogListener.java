package com.gadware.mvga.utils;

import androidx.appcompat.app.AlertDialog;

public interface OnCancelMonthDialogListener {
    public void onCancel(AlertDialog dialog);
}
