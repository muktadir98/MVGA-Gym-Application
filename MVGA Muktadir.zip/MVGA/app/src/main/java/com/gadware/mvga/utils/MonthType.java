package com.gadware.mvga.utils;

public enum MonthType {
    TEXT, NUMBER
}
