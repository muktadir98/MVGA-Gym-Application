package com.gadware.mvga.utils;

public interface DateMonthDialogListener {
    public void onDateMonth(int month, int startDate, int endDate, int year, String monthLabel);
}
